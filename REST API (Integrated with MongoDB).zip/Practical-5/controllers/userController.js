let users = [];

exports.addUser = (req, res) => {
  const { username, email } = req.body;
  if (!username || !email) {
    return res.status(400).json({ error: "Username and email required" });
  }
  users.push(req.body);
  res.status(201).json({ message: "User added", users });
};

exports.getUsers = (req, res) => {
  res.json(users);
};
