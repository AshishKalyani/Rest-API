let products = [];

exports.addProduct = (req, res) => {
  const { name, price } = req.body;
  if (!name || !price) {
    return res.status(400).json({ error: "Name and price required" });
  }
  products.push(req.body);
  res.status(201).json({ message: "Product added", products });
};

exports.getProducts = (req, res) => {
  res.json(products);
};
