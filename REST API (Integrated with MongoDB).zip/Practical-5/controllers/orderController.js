let orders = [];
const cartController = require("./cartController");

exports.placeOrder = (req, res) => {
  if (!req.body.items || req.body.items.length === 0) {
    return res.status(400).json({ error: "No items in order" });
  }
  orders.push(req.body);
  cartController.clearCart();
  res.json({ message: "Order placed", orders });
};

exports.getOrders = (req, res) => {
  res.json(orders);
};
