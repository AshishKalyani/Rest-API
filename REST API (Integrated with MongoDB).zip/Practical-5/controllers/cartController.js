let cart = [];

exports.addToCart = (req, res) => {
  const { product } = req.body;
  if (!product) {
    return res.status(400).json({ error: "Product required" });
  }
  cart.push(product);
  res.json({ message: "Added to cart", cart });
};

exports.getCart = (req, res) => {
  res.json(cart);
};

exports.clearCart = () => {
  cart = [];
};
